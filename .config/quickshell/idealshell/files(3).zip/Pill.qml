pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Effects
import "."

/**
 * Bare-bones pill: two modes only.
 *   "rest"  — idle pip clusters (Pips.qml), flush at the top of the screen.
 *   "hover" — pointer is over the pill, morphs into a small clock readout.
 * No surfaces, no media, no workspaces, no tray. Hover mechanism and morph
 * animation values are copied as-is from the full Pill.qml so behavior
 * matches exactly; only the surface/media/workspace logic was removed.
 */
Item {
    id: pill

    property real s: 1
    property string screenName: ""
    property var barWindow

    // Fed by a HoverHandler in shell.qml (see integration notes).
    property bool hovered: false
    property bool hoverLatch: false
    readonly property bool expanded: hoverLatch

    readonly property real restW: 130 * s
    readonly property real restH: 10 * s
    readonly property real hoverPad: 20 * s
    readonly property real hoverW: hoverRow.implicitWidth + 2 * hoverPad
    readonly property real hoverH: 58 * s
    readonly property real restCorner: 18 * s
    readonly property real openCorner: 22 * s

    readonly property string mode: expanded ? "hover" : "rest"

    readonly property size targetSize: mode === "hover"
        ? Qt.size(hoverW, hoverH)
        : Qt.size(Math.max(restW, restPips.implicitWidth + 36 * s), restH)
    readonly property real targetW: targetSize.width
    readonly property real targetH: targetSize.height

    width: targetW
    height: targetH

    readonly property real morphCloseness: {
        const d = Math.max(Math.abs(width - targetW), Math.abs(height - targetH));
        return 1 - Math.min(1, d / (110 * s));
    }

    property real morphRadius: mode === "rest" ? restCorner : openCorner

    Behavior on width { NumberAnimation { duration: Motion.morph; easing.type: Motion.easeMorph; easing.bezierCurve: Motion.morphCurve } }
    Behavior on height { NumberAnimation { duration: Motion.morph; easing.type: Motion.easeMorph; easing.bezierCurve: Motion.morphCurve } }
    Behavior on morphRadius { NumberAnimation { duration: Motion.morph; easing.type: Motion.easeMorph; easing.bezierCurve: Motion.morphCurve } }

    /**
     * Clock data source — copied as-is from the full Pill.qml. Self-contained,
     * only depends on Flags for the 12h/seconds format toggles.
     */
    QtObject {
        id: clock
        readonly property var loc: Qt.locale("en_US")
        readonly property var now: sysClock.date
        readonly property string timeFormat: (Flags.time12h ? "h:mm" : "HH:mm")
            + (Flags.clockSeconds ? ":ss" : "")
            + (Flags.time12h ? " AP" : "")
        readonly property string hhmm: Qt.formatTime(now, timeFormat)
        readonly property string date: loc.toString(now, "ddd d MMM")
    }

    SystemClock {
        id: sysClock
        precision: Flags.clockSeconds ? SystemClock.Seconds : SystemClock.Minutes
    }

    /**
     * Hover handling — copied as-is from the full Pill.qml. hovered is set by
     * a HoverHandler in shell.qml. graceTimer stops the pill snapping shut on
     * a brief flicker off the pointer, and won't fire mid-morph-animation.
     */
    onHoveredChanged: {
        if (hovered) {
            hoverLatch = true;
            graceTimer.stop();
        } else {
            graceTimer.restart();
        }
    }

    Timer {
        id: graceTimer
        interval: 300
        onTriggered: {
            if (pill.morphCloseness < 0.95) {
                graceTimer.restart();
                return;
            }
            pill.hoverLatch = false;
        }
    }

    Rectangle {
        id: body
        anchors.fill: parent
        radius: pill.morphRadius
        border.width: pill.mode === "rest" ? 0 : 1
        border.color: Theme.border
        opacity: pill.mode === "rest" ? 0 : 1
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: Motion.fast } }
        gradient: Gradient {
            GradientStop { position: 0.0; color: Qt.alpha(Theme.cardTop, Flags.pillOpacity) }
            GradientStop { position: 1.0; color: Qt.alpha(Theme.cardBot, Flags.pillOpacity) }
        }

        layer.enabled: true
        layer.effect: MultiEffect {
            shadowEnabled: true
            shadowColor: Qt.rgba(0, 0, 0, Theme.shadowOpacity)
            shadowBlur: 0.7
            shadowVerticalOffset: 3 * pill.s
        }
    }

    Item {
        id: rest
        anchors.fill: parent
        anchors.topMargin: -4 * pill.s
        opacity: pill.expanded ? 0 : Math.pow(pill.morphCloseness, 1.5)
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: pill.mode === "rest" ? Motion.fast : 260 } }

        Pips {
            id: restPips
            x: (rest.width - width) / 2
            y: (rest.height - height) / 2
            s: pill.s
            activeColor: Theme.vermLit
        }
    }

    Item {
        id: hover
        anchors.fill: parent
        opacity: pill.mode === "hover" ? Math.pow(pill.morphCloseness, 1.2) : 0
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: pill.mode === "hover" ? Motion.fast : 40 } }

        Column {
            id: hoverRow
            anchors.centerIn: parent
            spacing: 2 * pill.s
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: clock.hhmm
                color: Theme.cream
                font.family: Theme.font
                font.pixelSize: 18 * pill.s
                font.weight: Font.DemiBold
                font.features: { "tnum": 1 }
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: clock.date
                color: Theme.dim
                font.family: Theme.font
                font.pixelSize: 8.5 * pill.s
                font.weight: Font.Medium
                font.capitalization: Font.AllUppercase
                font.letterSpacing: 1.6 * pill.s
            }
        }
    }
}
