//@ pragma UseQApplication

import QtQuick
import Quickshell
import Quickshell.Wayland

/**
 * Bare-bones shell: one overlay PanelWindow per screen, hosting the pill.
 * No reserve/exclusion-zone window — the pill has no visible capsule at
 * rest, so there's nothing to leave room for. No IPC handlers, no surface
 * routing. Hover is detected via a window-wide HoverHandler and fed
 * straight into pill.hovered.
 */
ShellRoot {
    id: root

    Variants {
        model: Quickshell.screens

        PanelWindow {
            id: overlay
            required property var modelData
            readonly property real s: modelData ? modelData.height / 1080 : 1
            readonly property real topGap: 8 * s

            screen: modelData
            color: "transparent"
            WlrLayershell.layer: WlrLayer.Overlay
            exclusionMode: ExclusionMode.Ignore
            aboveWindows: true

            anchors { top: true; left: true; right: true }
            implicitHeight: pill.height + topGap

            mask: Region {
                item: pill
            }

            Pill {
                id: pill
                anchors.top: parent.top
                anchors.topMargin: overlay.topGap
                anchors.horizontalCenter: parent.horizontalCenter
                s: overlay.s
                screenName: overlay.modelData.name
                barWindow: overlay
            }

            HoverHandler {
                onHoveredChanged: pill.hovered = hovered
            }
        }
    }
}
